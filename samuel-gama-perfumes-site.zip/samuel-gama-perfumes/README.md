# Samuel Gama Perfumes

Loja virtual responsiva com catálogo público, contato por WhatsApp/Instagram e painel administrativo protegido por Supabase Auth + Row Level Security.

## O que já está pronto
- Visual preto e dourado, adaptado para celular.
- Catálogo com busca e filtro por categoria.
- Cadastro, edição, exclusão e ativação/ocultação de perfumes.
- Upload de fotos de produtos, banner e fundo.
- Configuração de nome, textos, cores, WhatsApp e Instagram.
- Login administrativo. A autorização é verificada no banco e reforçada por políticas RLS.
- Produtos e configurações persistem no Supabase.

## Para colocar no ar

### 1. Criar o banco
1. Crie um projeto em https://supabase.com.
2. No painel do projeto, abra **SQL Editor**.
3. Cole e execute todo o conteúdo de `supabase/schema.sql`.

### 2. Criar sua conta de administrador
1. No Supabase, abra **Authentication > Users** e adicione um usuário com seu e-mail e uma senha forte.
2. Copie o UUID desse usuário.
3. No SQL Editor, execute (substituindo pelo UUID real):
   ```sql
   insert into public.admin_users (user_id)
   values ('UUID-DA-SUA-CONTA');
   ```
4. Não compartilhe sua senha. Não coloque a senha no código do site.

### 3. Configurar o projeto
1. Copie `.env.example` para `.env.local`.
2. No Supabase, abra **Project Settings > API** e copie a Project URL e a chave `anon`/publishable para `.env.local`:
   ```env
   NEXT_PUBLIC_SUPABASE_URL=https://SEU-PROJETO.supabase.co
   NEXT_PUBLIC_SUPABASE_ANON_KEY=SUA_CHAVE_PUBLICA
   ```
3. Instale Node.js 20 ou superior.
4. Na pasta do projeto, execute:
   ```bash
   npm install
   npm run dev
   ```
5. Acesse `http://localhost:3000`. O painel fica em `http://localhost:3000/admin`.

### 4. Publicar
1. Envie a pasta para um repositório privado no GitHub.
2. Importe o repositório em https://vercel.com.
3. Em **Environment Variables**, cadastre as mesmas duas variáveis do `.env.local`.
4. Clique em Deploy. A Vercel fornece um endereço público; você pode conectar um domínio próprio depois.

## Segurança importante
- Nunca use a chave `service_role` no navegador ou em variáveis `NEXT_PUBLIC_*`.
- A conta só ganha permissão administrativa se o UUID for inserido manualmente na tabela `admin_users` pelo dono do projeto.
- O cadastro público de novas contas não está exposto no site.
- As políticas RLS do SQL são a proteção real; esconder a página não é considerado segurança.
- Imagens são públicas para exibição na loja; somente administradores podem enviar, atualizar ou apagar.
- Use uma senha forte e ative autenticação multifator na conta Supabase, se disponível.

## Contatos iniciais
- WhatsApp: 55 66 99258-5720
- Instagram: @samue_.g1

O site não inclui checkout ou pagamento online. O pedido é iniciado pelo WhatsApp para você confirmar disponibilidade, preço e entrega.
