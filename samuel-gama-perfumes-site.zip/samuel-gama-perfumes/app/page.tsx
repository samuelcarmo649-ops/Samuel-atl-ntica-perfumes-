"use client";

import { useEffect, useMemo, useState } from "react";
import { Instagram, MessageCircle, Search, ShieldCheck, Sparkles } from "lucide-react";
import { supabaseBrowser } from "@/lib/supabase";

type Product = { id: string; name: string; brand: string | null; description: string | null; price: number | null; image_url: string | null; category: string | null; active: boolean };
type Settings = { store_name: string; tagline: string; whatsapp: string; instagram: string; hero_title: string; hero_subtitle: string; banner_url: string | null; background_url: string | null; accent_color: string; background_color: string };

const defaults: Settings = {
  store_name: "SAMUEL GAMA", tagline: "PERFUMES", whatsapp: "5566992585720",
  instagram: "samue_.g1", hero_title: "Sua fragrância.\nSua presença.",
  hero_subtitle: "Encontre a essência que combina com você.", banner_url: null,
  background_url: null, accent_color: "#c9a45c", background_color: "#0b0b0b"
};

const money = (v: number | null) => v == null ? "Consulte o preço" : v.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
const cleanPhone = (v: string) => v.replace(/\D/g, "");

export default function Home() {
  const [products, setProducts] = useState<Product[]>([]);
  const [settings, setSettings] = useState<Settings>(defaults);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("Todos");

  useEffect(() => {
    const load = async () => {
      try {
        const db = supabaseBrowser();
        const [p, s] = await Promise.all([
          db.from("products").select("*").eq("active", true).order("created_at", { ascending: false }),
          db.from("store_settings").select("*").eq("id", 1).maybeSingle()
        ]);
        if (p.data) setProducts(p.data as Product[]);
        if (s.data) setSettings({ ...defaults, ...s.data });
      } catch (e) { console.warn(e); }
      setLoading(false);
    };
    load();
  }, []);

  const categories = useMemo(() => ["Todos", ...Array.from(new Set(products.map(p => p.category).filter(Boolean) as string[]))], [products]);
  const filtered = products.filter(p => (category === "Todos" || p.category === category) && (p.name + " " + (p.brand || "")).toLowerCase().includes(search.toLowerCase()));
  const wa = `https://wa.me/${cleanPhone(settings.whatsapp)}?text=${encodeURIComponent("Olá! Vim pelo site Samuel Gama Perfumes e gostaria de conhecer os perfumes.")}`;
  const ig = `https://instagram.com/${settings.instagram.replace(/^@/, "")}`;

  return <main style={{ "--gold": settings.accent_color, "--page": settings.background_color, backgroundImage: settings.background_url ? `linear-gradient(#080808bb,#080808dd),url("${settings.background_url}")` : undefined } as React.CSSProperties}>
    <header className="topbar">
      <a className="brand" href="#"><span className="brand-mark">SG</span><span>{settings.store_name}<small>{settings.tagline}</small></span></a>
      <nav><a href="#colecao">Coleção</a><a href="#sobre">Sobre</a><a href="#contato">Contato</a></nav>
      <a className="top-cta" href={wa} target="_blank" rel="noreferrer"><MessageCircle size={16}/> Fale comigo</a>
    </header>

    <section className="hero" style={settings.banner_url ? { backgroundImage: `linear-gradient(90deg,#080808ee 0%,#080808aa 55%,#08080844),url("${settings.banner_url}")` } : undefined}>
      <div className="hero-copy">
        <div className="eyebrow"><Sparkles size={14}/> PERFUMARIA & PERSONALIDADE</div>
        <h1>{settings.hero_title.split("\n").map((line, i) => <span key={i}>{line}<br/></span>)}</h1>
        <p>{settings.hero_subtitle}</p>
        <a className="gold-button" href="#colecao">Explorar perfumes <span>↗</span></a>
      </div>
      <div className="hero-stamp"><span>SG</span><small>ESSÊNCIA<br/>DE PRESENÇA</small></div>
      <div className="hero-bottom"><span>SELEÇÃO ESPECIAL</span><span>ESTILO • ELEGÂNCIA • IDENTIDADE</span></div>
    </section>

    <section id="colecao" className="collection section-wrap">
      <div className="section-heading"><div><div className="eyebrow">DESCUBRA SUA ESSÊNCIA</div><h2>Nossa <em>coleção</em></h2></div><p>Perfumes escolhidos para marcar presença em todos os momentos.</p></div>
      <div className="tools"><label className="search"><Search size={17}/><input value={search} onChange={e => setSearch(e.target.value)} placeholder="Buscar perfume..."/></label>
        <div className="filters">{categories.map(c => <button key={c} className={category === c ? "filter active" : "filter"} onClick={() => setCategory(c)}>{c}</button>)}</div>
      </div>
      {loading ? <p className="empty">Carregando coleção...</p> : filtered.length === 0 ? <div className="empty"><span>✧</span><h3>{products.length ? "Nenhum perfume encontrado" : "Sua vitrine está pronta para receber seus perfumes"}</h3><p>{products.length ? "Tente outra busca ou categoria." : "Os produtos que você cadastrar no painel administrativo aparecerão aqui."}</p></div> :
        <div className="product-grid">{filtered.map(p => <article className="product-card" key={p.id}><div className="product-image">{p.image_url ? <img src={p.image_url} alt={p.name}/> : <div className="image-placeholder"><span>SG</span><small>PERFUMES</small></div>}{p.category && <span className="product-tag">{p.category}</span>}</div><div className="product-info"><small>{p.brand || "SAMUEL GAMA"}</small><h3>{p.name}</h3><p>{p.description || "Uma fragrância para expressar sua personalidade."}</p><div className="product-bottom"><strong>{money(p.price)}</strong><a href={`https://wa.me/${cleanPhone(settings.whatsapp)}?text=${encodeURIComponent("Olá! Tenho interesse no perfume " + p.name + ". Ele está disponível?")}`} target="_blank" rel="noreferrer">Consultar <span>↗</span></a></div></div></article>)}</div>}
    </section>

    <section id="sobre" className="manifesto"><div className="manifesto-symbol">SG</div><div className="eyebrow">SAMUEL GAMA PERFUMES</div><h2>Mais que perfume.<br/><em>Uma assinatura pessoal.</em></h2><p>Cada fragrância conta uma história. Descubra a sua com atendimento próximo e escolha com confiança.</p></section>

    <footer id="contato"><div><a className="brand" href="#"><span className="brand-mark">SG</span><span>{settings.store_name}<small>{settings.tagline}</small></span></a><p>Encontre sua próxima fragrância favorita.</p></div><div className="footer-links"><a href={wa} target="_blank" rel="noreferrer"><MessageCircle size={17}/> WhatsApp</a><a href={ig} target="_blank" rel="noreferrer"><Instagram size={17}/> @{settings.instagram.replace(/^@/, "")}</a><a href="/admin" className="admin-link"><ShieldCheck size={15}/> Área administrativa</a></div><small className="copyright">© {new Date().getFullYear()} Samuel Gama Perfumes. Todos os direitos reservados.</small></footer>
  </main>;
}
