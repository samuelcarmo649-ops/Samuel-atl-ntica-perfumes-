import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Samuel Gama Perfumes | Sua fragrância, sua presença",
  description: "Conheça a seleção de perfumes Samuel Gama. Consulte disponibilidade e peça pelo WhatsApp."
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="pt-BR"><body>{children}</body></html>;
}
