"use client";

import { useEffect, useState } from "react";
import { supabaseBrowser } from "@/lib/supabase";
import { Instagram, LogOut, PackagePlus, Palette, Save, Settings, Trash2, Upload, X } from "lucide-react";

type Product = { id: string; name: string; brand: string | null; description: string | null; price: number | null; image_url: string | null; category: string | null; active: boolean };
type Store = { id?: number; store_name: string; tagline: string; whatsapp: string; instagram: string; hero_title: string; hero_subtitle: string; banner_url: string | null; background_url: string | null; accent_color: string; background_color: string };
const initial: Store = { store_name:"SAMUEL GAMA", tagline:"PERFUMES", whatsapp:"5566992585720", instagram:"samue_.g1", hero_title:"Sua fragrância.\nSua presença.", hero_subtitle:"Encontre a essência que combina com você.", banner_url:null, background_url:null, accent_color:"#c9a45c", background_color:"#0b0b0b" };
const blank = { name:"", brand:"", description:"", price:"", category:"", image_url:"", active:true };

export default function Admin() {
  const [db] = useState(() => supabaseBrowser());
  const [session, setSession] = useState<any>(null);
  const [authorized, setAuthorized] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [products, setProducts] = useState<Product[]>([]);
  const [settings, setSettings] = useState<Store>(initial);
  const [form, setForm] = useState(blank);
  const [editing, setEditing] = useState<string | null>(null);
  const [tab, setTab] = useState("products");
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState("");

  const refresh = async () => {
    const [p,s] = await Promise.all([db.from("products").select("*").order("created_at",{ascending:false}), db.from("store_settings").select("*").eq("id",1).maybeSingle()]);
    if (p.data) setProducts(p.data as Product[]);
    if (s.data) setSettings({ ...initial, ...s.data });
  };

  useEffect(() => {
    db.auth.getSession().then(async ({data}) => {
      setSession(data.session);
      if (data.session) {
        const {data: role} = await db.from("admin_users").select("user_id").eq("user_id", data.session.user.id).maybeSingle();
        if (role) { setAuthorized(true); await refresh(); }
        else setError("Este usuário não tem permissão de administrador.");
      }
    });
    const {data: listener} = db.auth.onAuthStateChange((_event, next) => setSession(next));
    return () => listener.subscription.unsubscribe();
  }, [db]);

  const login = async (e: React.FormEvent) => {
    e.preventDefault(); setError(""); setBusy(true);
    const {data,error} = await db.auth.signInWithPassword({email,password});
    if (error) setError("E-mail ou senha inválidos.");
    else {
      const {data: role} = await db.from("admin_users").select("user_id").eq("user_id", data.user.id).maybeSingle();
      if (role) { setSession(data.session); setAuthorized(true); await refresh(); }
      else { await db.auth.signOut(); setError("Acesso negado: sua conta não é administradora."); }
    }
    setBusy(false);
  };

  const logout = async () => { await db.auth.signOut(); setSession(null); setAuthorized(false); };
  const saveProduct = async (e: React.FormEvent) => {
    e.preventDefault(); setBusy(true); setNotice("");
    const payload = { name:form.name, brand:form.brand || null, description:form.description || null, price:form.price ? Number(form.price) : null, category:form.category || null, image_url:form.image_url || null, active:form.active };
    const result = editing ? await db.from("products").update(payload).eq("id",editing) : await db.from("products").insert(payload);
    if (result.error) setNotice("Erro ao salvar: " + result.error.message);
    else { setNotice("Perfume salvo com sucesso."); setForm(blank); setEditing(null); await refresh(); }
    setBusy(false);
  };
  const editProduct = (p: Product) => { setEditing(p.id); setForm({name:p.name,brand:p.brand||"",description:p.description||"",price:p.price?.toString()||"",category:p.category||"",image_url:p.image_url||"",active:p.active}); setTab("products"); window.scrollTo({top:0,behavior:"smooth"}); };
  const deleteProduct = async (id:string) => { if (!confirm("Excluir este perfume?")) return; const {error} = await db.from("products").delete().eq("id",id); setNotice(error ? error.message : "Produto excluído."); await refresh(); };
  const upload = async (file: File, target:"product"|"banner"|"background") => {
    const ext = file.name.split(".").pop() || "jpg";
    const path = `${Date.now()}-${Math.random().toString(36).slice(2)}.${ext}`;
    const {error} = await db.storage.from("store-images").upload(path,file,{upsert:false});
    if (error) { setNotice("Falha no envio da imagem: "+error.message); return; }
    const {data} = db.storage.from("store-images").getPublicUrl(path);
    if (target==="product") setForm(f=>({...f,image_url:data.publicUrl}));
    else setSettings(s=>({...s,[target==="banner"?"banner_url":"background_url"]:data.publicUrl}));
  };
  const saveSettings = async (e:React.FormEvent) => {
    e.preventDefault(); setBusy(true);
    const {error} = await db.from("store_settings").upsert({...settings,id:1});
    setNotice(error ? "Erro: "+error.message : "Aparência e contatos atualizados.");
    setBusy(false);
  };

  if (!authorized) return <main className="admin-page"><div className="login-card"><a href="/" className="back-link">← Voltar à loja</a><div className="login-logo">SG</div><div className="eyebrow">ÁREA RESTRITA</div><h1>Painel do <em>administrador</em></h1><p>Entre com sua conta autorizada para gerenciar a loja.</p><form onSubmit={login}><label>E-mail<input type="email" value={email} onChange={e=>setEmail(e.target.value)} required placeholder="seu@email.com"/></label><label>Senha<input type="password" value={password} onChange={e=>setPassword(e.target.value)} required placeholder="Sua senha"/></label>{error && <div className="error">{error}</div>}<button className="gold-button full" disabled={busy}>{busy?"Entrando...":"Entrar no painel"}</button></form><small className="muted">O acesso só funciona após a conta ser cadastrada como administradora no Supabase.</small></div></main>;

  return <main className="admin-page"><header className="admin-header"><a className="brand" href="/"><span className="brand-mark">SG</span><span>SAMUEL GAMA<small>PAINEL ADMINISTRATIVO</small></span></a><button className="logout" onClick={logout}><LogOut size={16}/> Sair</button></header>
    <div className="admin-shell"><div className="admin-intro"><div className="eyebrow">CONTROLE DA SUA LOJA</div><h1>Bem-vindo, <em>Samuel.</em></h1><p>Gerencie seus produtos, aparência e canais de atendimento.</p></div>
      <div className="admin-tabs"><button className={tab==="products"?"selected":""} onClick={()=>setTab("products")}><PackagePlus size={17}/> Produtos</button><button className={tab==="design"?"selected":""} onClick={()=>setTab("design")}><Palette size={17}/> Aparência e contatos</button></div>
      {notice && <div className="notice">{notice}<button onClick={()=>setNotice("")}><X size={14}/></button></div>}
      {tab==="products" ? <div className="admin-columns"><section className="admin-panel"><h2>{editing?"Editar perfume":"Adicionar perfume"}</h2><form className="admin-form" onSubmit={saveProduct}>
        <label>Nome do perfume<input value={form.name} onChange={e=>setForm({...form,name:e.target.value})} required placeholder="Ex.: Nome do perfume"/></label>
        <div className="two-fields"><label>Marca<input value={form.brand} onChange={e=>setForm({...form,brand:e.target.value})} placeholder="Marca"/></label><label>Categoria<input value={form.category} onChange={e=>setForm({...form,category:e.target.value})} placeholder="Masculino, feminino..."/></label></div>
        <label>Descrição<textarea value={form.description} onChange={e=>setForm({...form,description:e.target.value})} rows={3} placeholder="Conte um pouco sobre a fragrância"/></label>
        <label>Preço (R$)<input type="number" min="0" step="0.01" value={form.price} onChange={e=>setForm({...form,price:e.target.value})} placeholder="Deixe vazio para consultar"/></label>
        <label>Foto do perfume<input type="url" value={form.image_url} onChange={e=>setForm({...form,image_url:e.target.value})} placeholder="Cole o link da imagem"/></label>
        <label className="upload-control"><Upload size={16}/> Enviar foto do aparelho<input type="file" accept="image/*" onChange={e=>e.target.files?.[0]&&upload(e.target.files[0],"product")}/></label>
        {form.image_url && <img className="preview" src={form.image_url} alt="Prévia do perfume"/>}
        <label className="check-label"><input type="checkbox" checked={form.active} onChange={e=>setForm({...form,active:e.target.checked})}/> Exibir na loja</label>
        <div className="form-actions"><button className="gold-button" disabled={busy}><Save size={16}/> {busy?"Salvando...":"Salvar perfume"}</button>{editing&&<button type="button" className="secondary-button" onClick={()=>{setEditing(null);setForm(blank)}}>Cancelar</button>}</div>
      </form></section><section className="admin-panel"><h2>Seus perfumes <span className="count">{products.length}</span></h2>{products.length===0?<p className="muted">Você ainda não cadastrou perfumes.</p>:<div className="admin-product-list">{products.map(p=><div className="admin-product" key={p.id}>{p.image_url?<img src={p.image_url} alt=""/>:<div className="mini-placeholder">SG</div>}<div className="admin-product-text"><strong>{p.name}</strong><small>{p.brand||"Sem marca"} • {p.active?"Visível":"Oculto"}</small></div><button onClick={()=>editProduct(p)}>Editar</button><button className="delete" onClick={()=>deleteProduct(p.id)} aria-label="Excluir"><Trash2 size={16}/></button></div>)}</div>}</section></div>
      : <section className="admin-panel design-panel"><h2><Settings size={19}/> Personalizar sua loja</h2><form className="admin-form" onSubmit={saveSettings}>
        <div className="two-fields"><label>Nome da loja<input value={settings.store_name} onChange={e=>setSettings({...settings,store_name:e.target.value})}/></label><label>Subtítulo<input value={settings.tagline} onChange={e=>setSettings({...settings,tagline:e.target.value})}/></label></div>
        <label>Título principal<textarea rows={2} value={settings.hero_title} onChange={e=>setSettings({...settings,hero_title:e.target.value})}/></label><label>Texto de apresentação<input value={settings.hero_subtitle} onChange={e=>setSettings({...settings,hero_subtitle:e.target.value})}/></label>
        <div className="two-fields"><label>WhatsApp (com DDI e DDD, só números)<input value={settings.whatsapp} onChange={e=>setSettings({...settings,whatsapp:e.target.value})}/></label><label>Instagram (sem @)<input value={settings.instagram} onChange={e=>setSettings({...settings,instagram:e.target.value.replace(/^@/,"")})}/></label></div>
        <div className="two-fields"><label>Cor de destaque<input type="color" value={settings.accent_color} onChange={e=>setSettings({...settings,accent_color:e.target.value})}/></label><label>Cor de fundo<input type="color" value={settings.background_color} onChange={e=>setSettings({...settings,background_color:e.target.value})}/></label></div>
        <label>Imagem do banner<input type="url" value={settings.banner_url||""} onChange={e=>setSettings({...settings,banner_url:e.target.value||null})} placeholder="Cole o link do banner"/></label><label className="upload-control"><Upload size={16}/> Enviar banner do aparelho<input type="file" accept="image/*" onChange={e=>e.target.files?.[0]&&upload(e.target.files[0],"banner")}/></label>
        <label>Imagem de fundo<input type="url" value={settings.background_url||""} onChange={e=>setSettings({...settings,background_url:e.target.value||null})} placeholder="Cole o link do fundo"/></label><label className="upload-control"><Upload size={16}/> Enviar fundo do aparelho<input type="file" accept="image/*" onChange={e=>e.target.files?.[0]&&upload(e.target.files[0],"background")}/></label>
        <div className="form-actions"><button className="gold-button" disabled={busy}><Save size={16}/> Salvar personalização</button></div>
      </form></section>}
    </div>
  </main>;
}
