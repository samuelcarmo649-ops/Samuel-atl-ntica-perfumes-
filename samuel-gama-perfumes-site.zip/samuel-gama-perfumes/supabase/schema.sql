-- Samuel Gama Perfumes: banco, segurança (RLS) e armazenamento de imagens.
create extension if not exists pgcrypto;

create table if not exists public.admin_users (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  brand text,
  description text,
  price numeric(10,2),
  image_url text,
  category text,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.store_settings (
  id integer primary key check (id = 1),
  store_name text not null default 'SAMUEL GAMA',
  tagline text not null default 'PERFUMES',
  whatsapp text not null default '5566992585720',
  instagram text not null default 'samue_.g1',
  hero_title text not null default E'Sua fragrância.\\nSua presença.',
  hero_subtitle text not null default 'Encontre a essência que combina com você.',
  banner_url text,
  background_url text,
  accent_color text not null default '#c9a45c',
  background_color text not null default '#0b0b0b'
);

insert into public.store_settings (id) values (1) on conflict (id) do nothing;

alter table public.admin_users enable row level security;
alter table public.products enable row level security;
alter table public.store_settings enable row level security;

-- O público só lê produtos ativos. Administradores gerenciam todos os produtos.
create policy "public reads active products" on public.products for select using (active = true);
create policy "admins read all products" on public.products for select to authenticated
  using (exists (select 1 from public.admin_users a where a.user_id = auth.uid()));
create policy "admins insert products" on public.products for insert to authenticated
  with check (exists (select 1 from public.admin_users a where a.user_id = auth.uid()));
create policy "admins update products" on public.products for update to authenticated
  using (exists (select 1 from public.admin_users a where a.user_id = auth.uid()))
  with check (exists (select 1 from public.admin_users a where a.user_id = auth.uid()));
create policy "admins delete products" on public.products for delete to authenticated
  using (exists (select 1 from public.admin_users a where a.user_id = auth.uid()));

-- Configurações são públicas para exibir a loja, mas só administradores podem alterar.
create policy "public reads store settings" on public.store_settings for select using (true);
create policy "admins update store settings" on public.store_settings for update to authenticated
  using (exists (select 1 from public.admin_users a where a.user_id = auth.uid()))
  with check (exists (select 1 from public.admin_users a where a.user_id = auth.uid()));
create policy "admins insert store settings" on public.store_settings for insert to authenticated
  with check (exists (select 1 from public.admin_users a where a.user_id = auth.uid()));

-- A tabela de administradores só pode ser consultada pelo próprio usuário autenticado.
create policy "admin checks own role" on public.admin_users for select to authenticated
  using (user_id = auth.uid());

-- Bucket público para imagens da vitrine; somente administradores autenticados enviam/excluem.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('store-images', 'store-images', true, 5242880, array['image/jpeg','image/png','image/webp'])
on conflict (id) do nothing;

create policy "public reads store images" on storage.objects for select
  using (bucket_id = 'store-images');
create policy "admins upload store images" on storage.objects for insert to authenticated
  with check (bucket_id = 'store-images' and exists (select 1 from public.admin_users a where a.user_id = auth.uid()));
create policy "admins update store images" on storage.objects for update to authenticated
  using (bucket_id = 'store-images' and exists (select 1 from public.admin_users a where a.user_id = auth.uid()))
  with check (bucket_id = 'store-images' and exists (select 1 from public.admin_users a where a.user_id = auth.uid()));
create policy "admins delete store images" on storage.objects for delete to authenticated
  using (bucket_id = 'store-images' and exists (select 1 from public.admin_users a where a.user_id = auth.uid()));

-- Depois de criar sua conta em Authentication > Users, copie o UUID e rode:
-- insert into public.admin_users (user_id) values ('COLE-AQUI-O-UUID-DA-SUA-CONTA');
